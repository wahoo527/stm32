#include "data_logger.h"
#include "tracking.h" 
#include "console.h"
#include "Systick.h"
#include "Ser_Hal.h"
#include "AI_Hal.h"

static unsigned char Inspecting_nodes = 0;  //巡检节点记录, 数值记录   2 - 2号节点
static unsigned char Detection_node = 0; //待检测节点编号, 用位表示   0x5 - 0101 要检测1 3节点

/*
巡检标志记录 - 用位表示
0位 : 巡检状态记录   0-不巡检   1-巡检中
1位 : 小车状态记录   0-停止     1-运行
2位 : 急停标志记录   0-正常行驶 1-急停     
*/
static char Inspecting_flag = 0; //巡检标志记录

unsigned char Check_flag = 0; //K210 检测完成标志

void Node_Detection(void);


/**************************************************************************
函数功能：循迹函数 
入口参数：无
返 回 值：无
解释说明: main函数调用
		  二进制000 - 十六进制0x0	全白, 越界停止
		  二进制001 - 十六进制0x1	右转
		  二进制010 - 十六进制0x2	直行 
		  二进制011 - 十六进制0x3	右转
		  二进制100 - 十六进制0x4	左转
		  二进制101	- 十六进制0x5	停止
		  二进制110 - 十六进制0x6	左转
		  二进制111 - 十六进制0x7	检测地点
		  
**************************************************************************/
void Data_Logger(void)
{	
#if 0//if and else mid copy close
	char flag = Tracking();
	switch(flag)
	{
		case 0x00: Inspecting_flag &= ~(1<<1); Car_Stop_Pwm(); break;         //全白, 越界停止
		case 0x01: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Right_Pwm();} break;      //右转
		case 0x02: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Start_Pwm();} break;        //直线直行
		case 0x03: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Right_Pwm();} break;   	 //右转
		case 0x04: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Left_Pwm();} break;       //左转
		case 0x05: if((Inspecting_flag&0x5) == 1){Inspecting_Stop();} break;	//巡检结束 停止
		case 0x06: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Left_Pwm();} break; 		 //左转
		case 0x07: if((Inspecting_flag&0x5) == 1){Node_Detection();} break;   //节点检测
		case 0x08: Inspecting_flag &= ~(1<<1); Car_Stop_Pwm(); break;
	}
#else
	char flag = Tracking();
//	char speed_l = 0, speed_r = 0;
	
	printf("data_logger_before------%d-----data_logger.c59\r\n",flag);
	switch(flag)
	{
		case 0x00: Inspecting_flag &= ~(1<<1); Car_Stop(); break;         //000 全白, 越界停止
		
		case 0x01: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Run(SPEED_TREE, SPEED_ZERO);} break;      //001 右转
		case 0x02: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Run(SPEED_TREE, SPEED_TREE);} break;        //010 直线直行
		case 0x03: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Run(SPEED_TREE,SPEED_ZERO);} break;   	 //011 右转
		
		case 0x04: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Run(SPEED_ZERO, SPEED_TREE);} break;       //100 左转
		case 0x05: if((Inspecting_flag&0x5) == 1){Inspecting_Stop();} break;	//101 巡检结束 停止
		case 0x06: if((Inspecting_flag&0x5) == 1){Inspecting_flag |= (1<<1); Car_Run(SPEED_ZERO, SPEED_TREE);} break; 		 //110 左转
		case 0x07: if((Inspecting_flag&0x5) == 1){Inspecting_flag &= ~(0x1<<1); Node_Detection();} break;   //111 节点检测
		default: Inspecting_flag &= ~(1<<1); Car_Stop(); break;
	}
	printf("data_logger------%d-----data_logger.c59\r\n",flag);
#endif
}



/**************************************************************************
函数功能：巡检状态查询函数 
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Inspection_Status(void)
{ 
	char Data[12] = {0xBE, 0x22, 0x02};

	Data[5] = Inspecting_flag;

	if((Inspecting_flag&(0x1<<1)) == 0)  //运行状态 - 停止
	{
		Data[3] = 0x01;
		Data[4] = Inspecting_nodes;
		
		Ser_Hal_Send(Data, 12);
	}
	else 
	{
		Ser_Hal_Send(Data, 12);
	}
}

/**************************************************************************
函数功能：节点检测函数 
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Node_Detection(void)
{
	
	char Data[4] = {0xDE, 0x20};
	
	Inspecting_flag &= ~(0x1<<1);  //运行标志清零 - 停止
	Car_Stop_Pwm();	
	Inspecting_nodes++;
	if( (Detection_node & (0x1<<(Inspecting_nodes-1))) != 0) //需要检查
	{
		Check_flag = 0;
		
		AI_Hal_Send(Data, 2);
		printf("Check_flag------%d-------data_logger.c124\r\n",Check_flag);
		while(Check_flag == 0); //等待检查结束, 在接收中断中改变状态
		printf("Chaeck_flag_after------%d-------data_logger.c126\r\n",Check_flag);
		Inspecting_flag |= (0x1<<1);  //运行状态置一 - 运行
		Car_Start_Pwm();
		delay_ms(1000);
	}
	else  //不需要检查
	{
		delay_ms(1000);
		
		Inspecting_flag |= (0x1<<1);  //运行状态置一 - 运行
		Car_Start_Pwm();
	}
}


/**************************************************************************
函数功能：巡检状态紧急停止函数
入口参数：无
返 回 值：无
解释说明: 当小车处于停止状态时，不做任何事情，
          处于运行状态时, 需要停止，并且停下当前所有动作
**************************************************************************/
void Emergency_Stop(void)
{
	if((Inspecting_flag&(0x1<<1)) != 0)   //处于运行状态 
	{
		Inspecting_flag &= ~(0x1<<1);  //运行标志清零 - 停止
		
		Inspecting_flag |= (0x1<<2);  //急停标志置一
		Car_Stop_Pwm();	//小车停止
		Car_Stop_Pwm();
		Car_Stop_Pwm();
	}
	else 
	{
		return;
	}
}


/**************************************************************************
函数功能：巡检恢复函数
入口参数：无
返 回 值：无
解释说明: 当小车处于运行状态时，不做任何事情，
		  处于停止状态时,需要恢复运行，并且恢复所有动作
**************************************************************************/
void Recover(void)
{
	if((Inspecting_flag&(0x1<<2)) != 0) //处于急停
	{
		Inspecting_flag &= ~(0x1<<2);   //急停标志 清0
		Inspecting_flag |= (0x1<<1);  //运行标志置一 - 运行
		Car_Start_Pwm();
		//恢复其他操作
	}
	else
	{
		return;
	}
}




/**************************************************************************
函数功能：获取当前节点编号
入口参数：存放命令的数组
返 回 值：无
解释说明: 
**************************************************************************/
char Get_Inspecting_Nodes(void)
{
	return Inspecting_nodes;
}


/**************************************************************************
函数功能：巡检开始
入口参数：要检查的节点记录
返 回 值：无
解释说明: 
**************************************************************************/
void Inspecting_Start(unsigned char Inspecting_Node)
{
	char Data[12] = {0xDE, 0x22};
	AI_Hal_Send(Data, 2);
	
	
	Inspecting_flag = 0;
	Inspecting_flag |= (0x3<<0);  //运行标志置一 - 运行  巡检中
	Detection_node = Inspecting_Node;
	Car_Start_Pwm();
}

/**************************************************************************
函数功能：巡检结束
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Inspecting_Stop(void)
{
	char Data[12] = {0xDE, 0x21};
	AI_Hal_Send(Data, 2);
	
	Data[0] = 0xBE;
	Data[1] = 0x20;
	Ser_Hal_Send(Data, 12);
	
	Inspecting_flag = 0;    //检测标志清零
	Detection_node = 0; 	//待检测节点清零
	Inspecting_nodes = 0;   //节点记录清零
	Car_Stop_Pwm();
}


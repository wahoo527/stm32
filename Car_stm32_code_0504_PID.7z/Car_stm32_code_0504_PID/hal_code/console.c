#include "console.h"
#include "encoder.h"
#include "motor.h"
#include "Systick.h"
#include "pid.h"
#include "usart.h"
#include "mpu6050.h"



/*******************
*  @brief  小车移动函数
*  @param  Motor_l_SetSpeed:左轮 目标速度、
		   Motor_r_SetSpeed:右轮 目标速度
*  @return 无
*
*******************/
void Car_Control(float Motor_l_SetSpeed,float Motor_r_SetSpeed)
{
	int pwml = 0, pwmr = 0;
	
	//改变电机PID参数的目标速度
	Set_Target_Speed(Motor_l_SetSpeed, Motor_r_SetSpeed);
	
	//根据PID计算 输出作用于电机 (定时器里面有电机控制，我们这里还增加,是为了提高实时性)
	pwml = PID_realize('L');
	pwmr = PID_realize('R');

	Motor_Set(pwml, pwmr);
}

/**************************************************************************
函数功能：小车运行函数
入口参数：Motor_l_SetSpeed 小车左轮速度; Motor_r_SetSpeed 小车右轮速度
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Run(float Motor_l_SetSpeed,float Motor_r_SetSpeed)
{
	if(Motor_l_SetSpeed > 0 && Motor_r_SetSpeed > 0)
	{
		Motor_Run_A();
	}
	else if(Motor_l_SetSpeed < 0 && Motor_r_SetSpeed < 0)
	{
		Motor_l_SetSpeed = -Motor_l_SetSpeed;
		Motor_r_SetSpeed = -Motor_r_SetSpeed;
		Motor_Return_A();
	}
	else if(Motor_l_SetSpeed > 0 && Motor_r_SetSpeed < 0)
	{
		Motor_r_SetSpeed = -Motor_r_SetSpeed;
		Motor_Run_L();
		Motor_Rerun_R();
		
	}
	else if(Motor_l_SetSpeed < 0 && Motor_r_SetSpeed > 0)
	{
		Motor_l_SetSpeed = -Motor_l_SetSpeed;
		Motor_Rerun_L();
		Motor_Run_R();
	}
	Car_Control(Motor_l_SetSpeed, Motor_r_SetSpeed);
}

/**************************************************************************
函数功能：小车直行函数
入口参数：无
返 回 值：无
解释说明: 速度为speed_tree=3
**************************************************************************/
void Car_Start(void)
{
	Motor_Run_A();
	Car_Control(SPEED_TREE,SPEED_TREE);
}

/**************************************************************************
函数功能：小车直行函数 无PID
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Start_Pwm(void) 
{
	Motor_Run_A();
	Motor_Set(90,90);
}


/**************************************************************************
函数功能：小车停止函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Stop(void)
{
	Motor_Stop_A();
	Car_Control(SPEED_ZERO,SPEED_ZERO);//停止
	Motor_Set(0, 0);
}
void Car_Stop_Pwm(void) //无PID
{
	Motor_Stop_A();
	Motor_Set(0, 0);//停止
}

/**************************************************************************
函数功能：小车后退函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Return(void)
{
	Motor_Return_A();
	Car_Control(SPEED_TREE, SPEED_TREE);//后退
}

/**************************************************************************
函数功能：小车左转函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Left(void)
{
	Motor_Run_A();
	Car_Control(SPEED_TREE,SPEED_FIVE);//向左转弯		
}
void Car_Left_Pwm(void) //无PID
{
	Motor_Run_A();
	Motor_Set(60, 70); //左转
}

/**************************************************************************
函数功能：小车右转函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Right(void)
{
	Motor_Run_A();
	Car_Control(SPEED_FIVE, SPEED_TREE);//向右转弯
}
void Car_Right_Pwm(void) //无PID
{
	Motor_Run_A();
	Motor_Set(70, 60); //右转
}


/**************************************************************************
函数功能：小车左转90°函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Left_Ninety(void)
{
	Motor_Run_A();
	Car_Control(0, SPEED_FIVE);//左原地旋转	
	delay_ms(700);
	Car_Stop();
	delay_ms(10);
	Car_Start();
}


/**************************************************************************
函数功能：小车右转90°函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Right_Ninety(void)
{
	Motor_Run_A();
	Car_Control(SPEED_FIVE, 0);//右原地旋转	
	delay_ms(700);
	Car_Stop();
	delay_ms(10);
	Car_Start();
}



/**************************************************************************
函数功能：小车左转180°函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Left_Eighteen(void)
{
	Motor_Run_A();
	Car_Control(0, SPEED_FIVE);//左原地旋转	
	delay_ms(1400);
	Car_Stop();
	delay_ms(10);
	Car_Start();
}


/**************************************************************************
函数功能：小车右转180°函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Right_Eighteen(void)
{
	Motor_Run_A();
	Car_Control(SPEED_FIVE, 0);//右原地旋转	
	delay_ms(1400);
	Car_Stop();
	delay_ms(10);
	Car_Start();
}



/**************************************************************************
函数功能：小车绕行函数
入口参数：无
返 回 值：无
解释说明: 
**************************************************************************/
void Car_Detour(void)
{
	Car_Left_Ninety();
	delay_ms(1400);
	Car_Right_Ninety();
	delay_ms(2000);
	Car_Right_Ninety();
	delay_ms(1300);
	Car_Left_Ninety();
}

void Car_Detour_Person(void)
{
	Car_Start();
	delay_ms(3000);
	Car_Left_Ninety();
	delay_ms(1400);
	Car_Right_Ninety();
	delay_ms(2000);
	Car_Right_Ninety();
	delay_ms(1300);
	Car_Left_Ninety();
}

/**************************************************************************
函数功能：小车状态查询函数
入口参数：无
返 回 值：小车停止或者运行状态，0代表停止、1代表运行
解释说明: 
**************************************************************************/
int Car_Status_Inquiry(void)
{
	int Encoder_Left, Encoder_Right; 
	
	Encoder_Right = Read_Encoder(3);  
	Encoder_Left  = Read_Encoder(2);
	if(Encoder_Right+Encoder_Left == 0)
		return 0;	
	else 
		return 1;
}






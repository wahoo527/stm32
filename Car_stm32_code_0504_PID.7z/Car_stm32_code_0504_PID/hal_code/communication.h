#ifndef __COMMUNICATION_H
#define __COMMUNICATION_H

#include "stm32f10x.h"

//#include "AI_Hal.h"
//#include "Ser_Hal.h"
//#include "data_logger.h"
//#include "drive.h"


#define FLAG_TRACK  1
#define FLAG_DRIVE  2



void communication_init(int BaudRate);


#endif 


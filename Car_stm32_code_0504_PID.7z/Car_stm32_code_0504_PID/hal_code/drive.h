#ifndef  __DRIVER_H
#define  __DRIVER_H

#include "stm32f10x.h"   
//#include "hc_sr04.h"
//#include "console.h"
//#include "Ser_Hal.h"
//#include "AI_Hal.h"




void Auto_Drive(void);
void Manual_Drive(void);

void Manual_Drive_Start(void);
void Auto_Drive_Start(unsigned char End_Node);
void Auto_Drive_Stop(void);

void Manual_Drive_Control(char cmd);
void Auto_Drive_Control(char cmd);
void Drive_Status(void);

#endif

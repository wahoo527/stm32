#include "communication.h"
#include "usart.h"
#include "AI_Hal.h"
#include "Ser_Hal.h"
#include "data_logger.h"
#include "drive.h"

int mode_flag = 0; //模式记录-巡检 自动驾驶1(FLAG_TRACK) 手动驾驶2(FLAG_DRIVE)

static char voicce_cmd[2] = {0xDE, 0x10};  //播报定位 - 我在这里


/**************************************************************************
函数功能：（重定向）重写fputc函数，就是为了printf函数能够使用
								注意：需要添加#include <stdio.h>
								注意：魔术棒-->Target-->Use MircroLIB需要勾选上
入口参数：无
返 回 值：无
解释说明: 代码内使用printf函数, 就是在调用串口发送
**************************************************************************/
#include "usart.h"  		//Usart1
#include "bluetooth.h"		//Usart2
#include "K210.h"			//Usart3
int fputc(int ch, FILE*  file )
{
	Usart1_Send_Byte(ch);	//usart
//	Usart2_Send_Byte(ch);	//bluetooth
//	Usart3_Send_Byte(ch);	//K210

	return ch;
}


/**************************************************************************
函数功能：服务器协议解析
入口参数：无
返 回 值：无
**************************************************************************/
void server_protocol_analysis(void)
{
	static char rec_flag = 0;
	static char temp_data = 0, len = 0, data = 0, cmd = 0;
	
	
//	Ser_Hal_Send(&rec_flag, 1);
	temp_data = Ser_Hal_Read();
	
	if(rec_flag == 0)
    {
		if(temp_data == 0xAE)
		{
			rec_flag=1;
        }			
    }
    else if(rec_flag == 1)
    {
        cmd = temp_data;
		
		switch(cmd)
		{
			//基础命令
			case 0x10: rec_flag=0; Manual_Drive_Control(cmd); break;   /*停止函数()*/
			case 0x11: rec_flag=0; Manual_Drive_Control(cmd); break;   /*前进函数()*/
			case 0x12: rec_flag=0; Manual_Drive_Control(cmd); break;   /*后退函数()*/
			case 0x13: rec_flag=0; Manual_Drive_Control(cmd); break;   /*左转函数(度数)*/
			case 0x14: rec_flag=0; Manual_Drive_Control(cmd); break;   /*右转函数(度数)*/
			case 0x15: rec_flag=0; Manual_Drive_Control(cmd); break;   /*左前函数(度数)*/
			case 0x16: rec_flag=0; Manual_Drive_Control(cmd); break;   /*左后函数(度数)*/
			case 0x17: rec_flag=0; Manual_Drive_Control(cmd); break;   /*右前函数(度数)*/
			case 0x18: rec_flag=0; Manual_Drive_Control(cmd); break;   /*右后函数(度数)*/
			case 0x19: rec_flag=0; Drive_Status(); break;            /*状态查询 - 暂时取消*/
			case 0x1A: rec_flag=0; AI_Hal_Send(voicce_cmd, 2);break; /*播报定位函数()*/
			
			//巡检
			case 0x20: rec_flag=0; mode_flag = FLAG_TRACK; Inspecting_Start(0xff); break; //自动巡检
			case 0x21: rec_flag=2; mode_flag = FLAG_TRACK; break;  //手动巡检
			case 0x22: rec_flag=0;if(mode_flag == FLAG_TRACK){Inspection_Status();} break;//巡检状态查询
			case 0x23: rec_flag=0;if(mode_flag == FLAG_TRACK){Emergency_Stop();} break;//急停
			case 0x24: rec_flag=0;if(mode_flag == FLAG_TRACK){Recover();} break;	//恢复
			
			//无人驾驶
			case 0x30: rec_flag=2;  break; //驾驶_flag = 1;
			case 0x31: rec_flag=0; mode_flag = FLAG_DRIVE; Manual_Drive_Start(); break; //开始手动驾驶();驾驶_flag = 1;
			case 0x32: rec_flag=0; mode_flag = 0; Auto_Drive_Stop(); break; //驾驶_flag = 0;
		}
	}
	else if(rec_flag == 2)
    {
		len = temp_data;
		if(len == 0x1)
		{
			rec_flag=3;
		}
	}
	else if(rec_flag == 3)
    {
		data = temp_data;
		
		if( cmd == 0x21)//手动巡检 data表示要检测的位置
		{
			rec_flag=0;
				
			Inspecting_Start(data);	
		}
		else if(cmd == 0x30)//自动驾驶, data表示终点
		{
			rec_flag=0;
			mode_flag = FLAG_DRIVE;
			Auto_Drive_Start(data); 
		}
	}
}

/**************************************************************************
函数功能：K210协议解析
入口参数：无
返 回 值：无
**************************************************************************/
void AI_protocol_analysis(void)
{
	static char rec_flag = 0;
	static unsigned int i = 0, pic_len = 0;
	static char data[13] = {0xBE, 0x21, 0x00};
	char temp_data = 0;
	
	temp_data = AI_Hal_Read();
//	Ser_Hal_Send( &temp_data , 1);
//	Ser_Hal_Send( &rec_flag , 1);
	
	#if  1
	if(rec_flag == 0)
    {
		if(temp_data == 0xCE)
			rec_flag = 1;
        
		else
			rec_flag = 0;
    }
    else if(rec_flag == 1)
    {		
		switch(temp_data) //cmd
		{
			//巡检
			case 0x20: rec_flag=2; break;  //巡检结果接收
			
			//无人驾驶 - 状态记录,上报状态+距离(暂定)
			case 0x30: rec_flag=0; if(mode_flag == FLAG_DRIVE) Auto_Drive_Control(temp_data); break; /*直行()*/
			case 0x31: rec_flag=0; if(mode_flag == FLAG_DRIVE) Auto_Drive_Control(temp_data); break; /*左转()*/
			case 0x32: rec_flag=0; if(mode_flag == FLAG_DRIVE) Auto_Drive_Control(temp_data); break; /*右转()*/
			case 0x33: rec_flag=0; if(mode_flag == FLAG_DRIVE) Auto_Drive_Control(temp_data); break; /*掉头()*/
			case 0x34: rec_flag=0; if(mode_flag == FLAG_DRIVE) Auto_Drive_Control(temp_data); break; /*绕行()*/
			case 0x35: rec_flag=0; if(mode_flag == FLAG_DRIVE) Auto_Drive_Control(temp_data); break; /*行人暂停()*/
			case 0x36: rec_flag=0; if(mode_flag == FLAG_DRIVE) {Auto_Drive_Control(temp_data); mode_flag = 0; }break; /*终点到达()*/
		}
	}
	
	else if(rec_flag == 2)
    {
		if(temp_data == 0)  //len
		{
			rec_flag = 0;
			
			data[2] = 0x1;
			data[3] = Get_Inspecting_Nodes();
			data[4] = 0x0;
			data[5] = 0x0;
			data[6] = 0x0;
			data[7] = 0x0;
			data[8] = 0x0;
			data[9] = 0x0;
			data[10] = 0x0;
			data[11] = 0x0;
			data[12] = 0x0;
			Ser_Hal_Send(data, 12);
			
			Check_flag = 1; //继续行驶
		}
		else
		{
			rec_flag=3;
			
			data[2] = 0x9;
			data[3] = Get_Inspecting_Nodes();
			
			i = 4;
		}
	}
	else if(rec_flag == 3)
    {
		data[i] = temp_data;
		i++;
		
		if(i == 12) //接收完 裂缝坐标(4) 图片大小(4)
		{
			rec_flag = 4;
			i = 0;	
			pic_len = data[8]<<24 | (data[9]<<16) | (data[10]<<8) | (data[11]<<0);
			
			Ser_Hal_Send(data, 12);
		}
	}
	else if(rec_flag == 4)
    {
		Ser_Hal_Send( (char *)&temp_data, 1 );
		i++;

		if(i == pic_len) //接收完成
		{
			i = 0;
			rec_flag = 0;
			
			Check_flag = 1; //继续行驶
		}
	}
	#endif
}


/**************************************************************************
函数功能：通信初始化函数
入口参数：通信波特率
返 回 值：无
**************************************************************************/
void communication_init(int BaudRate)
{
	AI_Hal_Init(BaudRate);
	Ser_Hal_Init(BaudRate);
	
	AI_Hal_Reg(&AI_protocol_analysis);
	Ser_Hal_Reg(&server_protocol_analysis);
}






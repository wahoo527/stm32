#ifndef __AI_HAL_H
#define __AI_HAL_H

#include "stm32f10x.h"     


void AI_Hal_Init(int BaudRate);
void AI_Hal_Reg(void (*pfunc)(void));
unsigned  char AI_Hal_Read(void);
void AI_Hal_Send(char *Data, int Len);
void AI_Hal_Send_Str(char *Str);

#endif 

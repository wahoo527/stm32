#ifndef __CONSOLE_H
#define __CONSOLE_H

#include "stm32f10x.h" 
//#include "encoder.h"
//#include "PID.h"
//#include "TB6612.h"
//#include "Systick.h"

#define SPEED_ZERO 0
#define SPEED_ONE 15
#define SPEED_TWO 30
#define SPEED_TREE 45
#define SPEED_FOUR 60
#define SPEED_FIVE 75

void Car_Control(float Motor_l_SetSpeed,float Motor_r_SetSpeed);
void Car_Run(float Motor_l_SetSpeed,float Motor_r_SetSpeed);

void Car_Start(void);
void Car_Start_Pwm(void);

void Car_Stop(void);
void Car_Stop_Pwm(void);

void Car_Return(void);

void Car_Left(void);
void Car_Left_Pwm(void);

void Car_Right(void);
void Car_Right_Pwm(void);

void Car_Left_Ninety(void);
void Car_Right_Ninety(void);
void Car_Left_Eighteen(void);
void Car_Right_Eighteen(void);

void Car_Detour(void);
void Car_Detour_Person(void);
	
int  Car_Status_Inquiry(void);


#endif 

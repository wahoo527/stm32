#ifndef __SER_HAL_H
#define __SER_HAL_H

#include "stm32f10x.h"     


void Ser_Hal_Init(int BaudRate);
void Ser_Hal_Reg(void (*pfunc)(void));
unsigned char Ser_Hal_Read(void);
void Ser_Hal_Send(char *Data, int Len);


#endif 

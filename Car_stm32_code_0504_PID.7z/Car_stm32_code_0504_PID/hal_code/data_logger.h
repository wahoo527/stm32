#ifndef __DATA_LOGGER_H
#define __DATA_LOGGER_H

#include "stm32f10x.h"     
//#include "infrared.h" 
//#include "console.h"
//#include "Ser_Hal.h"
//#include "AI_Hal.h"

extern unsigned char Detection_node;  //�����ڵ�
extern unsigned char Check_flag; //K210 �����ɱ�־

void Data_Logger(void);  //
void Inspection_Status(void);
void Emergency_Stop(void);
void Recover(void);
char Get_Inspecting_Nodes(void);
void Inspecting_Start(unsigned char Inspecting_Node);
void Inspecting_Stop(void);


#endif 

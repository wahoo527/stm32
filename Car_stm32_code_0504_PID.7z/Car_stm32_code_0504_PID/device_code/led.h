#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"                  // Device header

void led_c13_init(void);
void led_c13_on(void);
void led_c13_off(void);


#endif
